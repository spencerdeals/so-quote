document.getElementById('captureBtn').addEventListener('click', async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

  chrome.scripting.executeScript({
    target: { tabId: tab.id },
    func: () => {
      const title = document.title;
      const priceEl = document.querySelector('[class*=price], [class*=Price]');
      const price = priceEl ? priceEl.innerText : 'Not found';
      return { title, price };
    }
  }, (results) => {
    const result = results[0].result;
    document.getElementById('output').textContent =
      `Title: ${result.title}\nPrice: ${result.price}`;
  });
});
